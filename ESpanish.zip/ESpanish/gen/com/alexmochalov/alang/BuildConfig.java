/** Automatically generated file. DO NOT MODIFY */
package com.alexmochalov.alang;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}